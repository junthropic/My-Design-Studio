"""Design Studio import: Blender Scripting > Open > Run Script. Adds a new scene; preserves existing scenes."""
import bpy, json, math
from pathlib import Path
root=Path(__file__).resolve().parent
data=json.loads((root/'scene.json').read_text(encoding='utf-8'))
m=data['motion']; tokens=data['tokens']; unit=.01
def color(value, fallback):
    if value and value.startswith('{'): value=tokens.get(value[1:-1],fallback)
    value=value or fallback
    channels=[int(value[n:n+2],16)/255 for n in (1,3,5)]
    return tuple(c/12.92 if c<=.04045 else ((c+.055)/1.055)**2.4 for c in channels)+(1,)
scene=bpy.data.scenes.new(data['name'])
if bpy.context.window: bpy.context.window.scene=scene
scene.render.resolution_x=m['width']; scene.render.resolution_y=m['height']; scene.render.resolution_percentage=100
scene.render.fps=m['fps']; scene.frame_start=1; scene.frame_end=sum(s['durationFrames'] for s in m['scenes'])
scene.render.film_transparent=m.get('transparent',False)
scene.view_settings.view_transform='Standard'; scene.view_settings.exposure=0; scene.view_settings.gamma=1
try: scene.view_settings.look='None'
except: pass
try: scene.render.engine='BLENDER_EEVEE_NEXT'
except: scene.render.engine='BLENDER_EEVEE'
world=bpy.data.worlds.new('Studio World'); scene.world=world; world.use_nodes=True; world.node_tree.nodes['Background'].inputs[0].default_value=color(tokens['color.bg'], '#000000')
camera_data=bpy.data.cameras.new('Studio Camera'); camera=bpy.data.objects.new('Studio Camera',camera_data);scene.collection.objects.link(camera);scene.camera=camera
camera.location=(m['width']*unit/2,-m['height']*unit/2,100);camera_data.type='ORTHO';camera_data.ortho_scale=m['width']*unit;camera_data.sensor_fit='HORIZONTAL'
assets={a['id']:a for a in data['assets']}
def material(name,rgba,opacity=1,image=None):
    mat=bpy.data.materials.new(name);mat.use_nodes=True;n=mat.node_tree.nodes;n.clear();links=mat.node_tree.links
    out=n.new('ShaderNodeOutputMaterial');emission=n.new('ShaderNodeEmission');emission.inputs['Color'].default_value=rgba
    transparent=n.new('ShaderNodeBsdfTransparent');mix=n.new('ShaderNodeMixShader');mix.inputs[0].default_value=opacity
    links.new(transparent.outputs[0],mix.inputs[1]);links.new(emission.outputs[0],mix.inputs[2]);links.new(mix.outputs[0],out.inputs['Surface'])
    if image:
        texture=n.new('ShaderNodeTexImage');texture.image=bpy.data.images.load(str(root/image['relativePath']),check_existing=True)
        if image['mime'].startswith('video/'):
            texture.image.source='MOVIE';texture.image_user.use_auto_refresh=True;texture.image_user.frame_duration=scene.frame_end
        texture.image.colorspace_settings.name='sRGB';links.new(texture.outputs['Color'],emission.inputs['Color'])
        multiply=n.new('ShaderNodeMath');multiply.operation='MULTIPLY';multiply.inputs[1].default_value=opacity;links.new(texture.outputs['Alpha'],multiply.inputs[0]);links.new(multiply.outputs[0],mix.inputs[0])
    if hasattr(mat,'surface_render_method'):mat.surface_render_method='DITHERED'
    elif hasattr(mat,'blend_method'):mat.blend_method='BLEND'
    return mat,mix
def quad(name,w,h,ellipse=False):
    if ellipse:
        vertices=[(math.cos(i*math.tau/64)*w/2,math.sin(i*math.tau/64)*h/2,0) for i in range(64)];faces=[tuple(range(64))]
    else:vertices=[(-w/2,-h/2,0),(w/2,-h/2,0),(w/2,h/2,0),(-w/2,h/2,0)];faces=[(0,1,2,3)]
    mesh=bpy.data.meshes.new(name);mesh.from_pydata(vertices,[],faces);mesh.update();obj=bpy.data.objects.new(name,mesh);scene.collection.objects.link(obj)
    uv=mesh.uv_layers.new(name='UVMap')
    for loop in mesh.loops: v=mesh.vertices[loop.vertex_index].co;uv.data[loop.index].uv=(v.x/w+.5,v.y/h+.5)
    return obj
if not m.get('transparent'):
    bg=quad('Background',m['width']*unit,m['height']*unit);bg.location=(m['width']*unit/2,-m['height']*unit/2,-1);bg.data.materials.append(material('Background',color(tokens['color.bg'],'#000000'))[0])
offset=0
for s in m['scenes']:
    for index,e in enumerate(s['elements']):
        kind=e['type'];obj=None;image=None
        if kind=='text':
            curve=bpy.data.curves.new(e['id'],'FONT');curve.body=e.get('text','');curve.size=e.get('fontSize',36)*unit;curve.space_line=float(tokens['font.lineHeight']);curve.align_x='LEFT';curve.align_y='TOP_BASELINE';curve.extrude=0
            obj=bpy.data.objects.new(e['id'],curve);scene.collection.objects.link(obj)
        elif kind in ('shape','image','video'):
            if kind in ('image','video'):
                image=assets.get(e.get('assetId'))
                if not image:continue
            obj=quad(e['id'],e['w']*unit,e['h']*unit,e.get('shape')=='ellipse')
        if obj is None:continue
        is_text=kind=='text';dx=0 if is_text else e['w']/2;dy=e.get('fontSize',36) if is_text else e['h']/2
        obj.location=((e['x']+dx)*unit,-(e['y']+dy)*unit,index*.001);obj.rotation_euler.z=-math.radians(e.get('rotation',0))
        mat,mix=material(e['id'],color(e.get('color') if is_text else e.get('fill'),tokens['color.text'] if is_text else tokens['color.accent']),e.get('opacity',1),image);obj.data.materials.append(mat)
        start=offset+e.get('startFrame',0)+1;end=offset+min(s['durationFrames'],e.get('endFrame',s['durationFrames']))
        for frame,hidden in [(1,True),(max(1,start-1),True),(start,False),(end,False),(end+1,True)]:
            obj.hide_render=hidden;obj.hide_viewport=hidden;obj.keyframe_insert('hide_render',frame=frame);obj.keyframe_insert('hide_viewport',frame=frame)
        if image and image['mime'].startswith('video/'):
            for node in mat.node_tree.nodes:
                if node.type=='TEX_IMAGE':node.image_user.frame_start=offset+1
        for key in sorted(e.get('keyframes',[]),key=lambda k:k['frame']):
            frame=offset+key['frame']+1;value=key['value'];prop=key['property']
            if prop=='x':obj.location.x=(float(value)+dx)*unit;obj.keyframe_insert('location',index=0,frame=frame)
            elif prop=='y':obj.location.y=-(float(value)+dy)*unit;obj.keyframe_insert('location',index=1,frame=frame)
            elif prop=='rotation':obj.rotation_euler.z=-math.radians(float(value));obj.keyframe_insert('rotation_euler',index=2,frame=frame)
            elif prop=='scale':obj.scale=(float(value),float(value),1);obj.keyframe_insert('scale',frame=frame)
            elif prop=='opacity' and not image:mix.inputs[0].default_value=float(value);mix.inputs[0].keyframe_insert('default_value',frame=frame)
        if obj.animation_data and obj.animation_data.action:
            try:
                for curve in obj.animation_data.action.fcurves:
                    for key in curve.keyframe_points:key.interpolation='CONSTANT' if 'hide_' in curve.data_path else 'LINEAR'
            except AttributeError:pass
    offset+=s['durationFrames']
scene.frame_set(1)
print('Design Studio import complete. Review manifest.json; save .blend manually.')
