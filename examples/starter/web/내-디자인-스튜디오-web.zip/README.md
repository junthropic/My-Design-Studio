# 내 디자인 스튜디오

루트 index.html을 열면 정적 웹사이트를 사용할 수 있습니다. 모든 페이지와 자산을 같은 위치에 유지하세요. 검색, 숫자 정렬, 사례·행 상세, FAQ, 대시보드 탭은 실제로 동작합니다.

React 소스는 react/에 있습니다. 해당 폴더에서 npm install 후 npm run dev 또는 npm run build를 사용합니다. 정적 페이지와 React 소스는 동일한 생성 HTML과 동작을 사용합니다.

요청 글꼴: Pretendard. Pretendard 웹폰트와 OFL 라이선스는 fonts/에 포함되어 있습니다. 업로드한 글꼴도 자산으로 포함됩니다. 추가 글꼴의 사용권과 배포 허용 범위를 확인하세요.
